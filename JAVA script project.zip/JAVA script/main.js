function total(){
    let bill=getElementById("bill").value; //value set by the user.

    let tip;
    if(bill>=100){tip=((bill*10)/100)}; // for the bill>=100$ tip is 10% of the bill
    if(bill>=300){tip=((bill*5)/100)}; // for the bill>=300$ tip is 5% of the bill
    if(bill>=500){tip=((bill*3)/100)}; // for the bill>=500$ tip is 3% of the bill
    document.getElementById("tip").value=tip;

    let result; //total calculation
    result=parseFloat(bill) + parseFloat(tip); //total will be the value set by user + value of the tip.
    document.getElementById("result").value=result; //total to pay based on the result.
}
    

